package com.example.demo;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity // This tells Hibernate to make a table out of this class
public class Book {
  @Id
  @GeneratedValue(strategy=GenerationType.AUTO)
  private int id;

  private String book_name;
  
  private String author;
  
  private int a_copies;
  
  private int tot_copies;
  
  public int getId() {
    return id;
  }

  public void setId(int id) {
    this.id = id;
  }

  public String getName() {
    return book_name;
  }

  public void setName(String name) {
    this.book_name = name;
  }

  public String getAuthor() {
    return author;
  }

  public void setAuthor(String author) {
    this.author = author;
  }
  
  public Integer getCopies() {
	  return a_copies;
  }

  public void setCopies(Integer copies) {
    this.a_copies = copies;
  }
  public Integer getTotCopies() {
	  return tot_copies;
  }

  public void setTotCopies(Integer tot_copies) {
    this.tot_copies = tot_copies;
  }
}